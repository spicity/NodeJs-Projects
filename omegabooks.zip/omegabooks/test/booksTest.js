let chai = require('chai');
let chaiHttp = require('chai-http');
let server = require('../app');
let should = chai.should();

chai.use(chaiHttp);

describe('Books', function () {
	//Test the GET route
	describe('GET /books', function () {
		it('It Should GET all the books', function (done) {
			chai.request(server)
				.get('/books')
				.end(function (err, res) {
					res.should.have.status(200);
					res.body.should.be.a('array');
					res.body.length.should.be.eql(4);
					done();
				});
		});
	});//end of GET /books

	//Test the POST route
	describe('POST /books', function () {
		it('It should not POST a book without Name field', function (done) {
			let book = {
				author: "J.R.R Tolkien",
				year: 1954
			}
			chai.request(server).post('/books').send(book).end(function (err, res) {
				res.should.have.status(200);
				res.body.should.be.a('object');
				res.body.should.have.property('errors');
				res.body.should.have.property('errors').eql('Name is required field');
				done();
			})
		});

		it('It should POST a book successfully', function (done) {
			let book = {
				name:"Catch 23",
				author: "J.R.R Tolkien",
				year: 1954
			}
			chai.request(server).post('/books').send(book).end(function (err, res) {
				res.should.have.status(200);
				res.body.should.be.a('object');
				res.body.should.have.property('message');
				//res.body.should.have.body('book');
				done();
			})
		});
	});
});

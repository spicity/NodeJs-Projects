var express = require('express');
var router = express.Router();

var books = [
    {id:1, name: "Birds of the Indian SubContinent", author: "Grimette & Inskipp",year:2012 },
    {id:2, name: "Harry Potter and the Order of the Phoenix", author: "J.K.Rowling", year:2007 },
     {id:3, name: "Catch 22", author: "Joseph Heller", year:1992 },
      {id:4, name: "The Camera", author: "Ansel Adams", year:1950 }
]

/* Get books list */
router.get('/', function(req,res,next){
    res.send(books);
});

// // Get a book by it's ID'
function findBook(id){
    for(var i=0;i < books.length; i++){
        if(books[i].id === id){
            return {"book": books[i],"index":1};
        }
    }
    return null;

}

// //Remove a book by its id
// function removeBook(id){

// }
router.get("/:id", function(req,res,next){
    var returnVal = findBook(parseInt(req.params.id,10));
    if(returnVal === null){
        res.sendStatus(404);

    }else {
        res.json(returnVal.book);
    }
});

router.post('/', function(req, res, next){
    var book = req.body;
    if(!book.name){
        res.json({ errors: "Name is required field" });
    } else {
        lastId = books[books.length - 1].id;
        book.id = lastId + 1;
        books.push(book);
        res.json({ message: "Book successfully added!", book});    
    }
});

router.put("/:id", function(req,res){
    var book = req.body;
    var returnVal = findBook(parseInt(req.params.id,10));
    if(null === returnVal){
        console.log('could not find book' + returnVal);
        res.sendStatus(404);

    }else {
        books[returnVal.index] = book;
        res.json( { message: "Book Updated!",book});
    }
});

module.exports = router;
